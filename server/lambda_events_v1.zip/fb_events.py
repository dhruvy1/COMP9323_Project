import facebook
import json
import re
import requests
from sys import argv

# set access token and version of fb api
graph = facebook.GraphAPI(
    access_token="425065081221660|Z14Prd648CGC7pkGiqkKBTyfrDk", version=2.10)


def getPageEvents(name, result_limit):
    if not name.strip() or result_limit < 1:
        print("You supplied an empty page name or limit < 1")
        return

    # set the event fields that we will need
    event_fields = "id, name, description, start_time, end_time, place, cover"
    # get page events, providing page name, event fields and the result limit
    events_dict = graph.get_connections(
        id=name, fields=event_fields, connection_name="events", limit=result_limit)

    for event in events_dict["data"]:
        payload = {
            "facebook_id": event["id"],
            "name": event["name"],
            "start_date": str(getDateFromTime(event["start_time"])),
            "start_time": str(filterTime(event["start_time"])),
        }
        if "end_time" in event:
            payload["end_date"] = str(getDateFromTime(event["end_time"]))
            payload["end_time"] = str(filterTime(event["end_time"]))
        if "description" in event:
            payload["description"] = event["description"]
        if "place" in event:
            payload["place_name"] = event["place"]["name"]
            if "location" in event["place"]:
                if "city" in event["place"]["location"]:
                    payload["city"] = event["place"]["location"]["city"]
                if "country" in event["place"]["location"]:
                    payload["country"] = event["place"]["location"]["country"]
                if "latitude" in event["place"]["location"]:
                    payload["latitude"] = event["place"]["location"]["latitude"]
                if "longitude" in event["place"]["location"]:
                    payload["longitude"] = event["place"]["location"]["longitude"]
                if "state" in event["place"]["location"]:
                    payload["state"] = event["place"]["location"]["state"]
                if "street" in event["place"]["location"]:
                    payload["street"] = event["place"]["location"]["street"]
                if "zip" in event["place"]["location"]:
                    payload["zip"] = event["place"]["location"]["zip"]
        if "cover" in event:
            payload["cover_id"] = event["cover"]["id"]
            payload["source_url"] = event["cover"]["source"]
        payload["created_by"] = "Facebook"

        postToRestServer(payload)


def getDateFromTime(time):
    return re.sub(r"T.*", "", time)


def filterTime(time):
    return re.sub(r"T.*", "", re.sub(r"^.*T", "", time))


def postToRestServer(payload):
    url = "http://52.65.129.3:8000/api/events/"
    headers = {"Content-Type": "application/json",
               "Accept": "application/json"}
    response = requests.post(url, data=json.dumps(payload), headers=headers)
    print(response)


if __name__ == "__main__":
    getPageEvents('ArcUNSW', 10)
